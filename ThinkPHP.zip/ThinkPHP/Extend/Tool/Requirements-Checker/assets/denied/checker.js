fileProtectionChecker = true;
